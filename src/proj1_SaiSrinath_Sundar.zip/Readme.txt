Readme:
The required queries can be done using the command line.
If the query is similar to Question II query 1: Please run QueryII.java
If the query is similar to Question II query 2: Please run QueryIIq2.java
If the query is similar to Question II query 3: Please run QueryIIq3.java
If the query is similar to Question II query 4: Please run QueryIIq4.java
If the query is similar to Question II query 5: Please run QueryIIq5.java
If the query is similar to Question II query 6: Please run QueryIIq6.java
If the query is similar to Question III : Please run QueryIII.java